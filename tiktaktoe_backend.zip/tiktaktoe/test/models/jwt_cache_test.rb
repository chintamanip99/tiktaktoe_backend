require "test_helper"

class JwtCacheTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
