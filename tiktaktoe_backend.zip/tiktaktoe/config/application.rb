require_relative "boot"

require "rails/all"

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module Tiktaktoe
  class Application < Rails::Application
    # Initialize configuration defaults for originally generated Rails version.
    config.load_defaults 6.1
    config.secret_key_base = "1897f1d27d240f88c2961cd4fde10e4dfeae26e8bcea280209673ce8c705243f40dff54ae8e384d66a35588c0dad473b037373cbce0c849b4b1f002721a19343"
    config.skip_session_storage = [:http_auth, :token_auth]
    # Configuration for the application, engines, and railties goes here.
    #
    # These settings can be overridden in specific environments using the files
    # in config/environments, which are processed later.
    #
    # config.time_zone = "Central Time (US & Canada)"
    # config.eager_load_paths << Rails.root.join("extras")
    config.hosts << "192.168.1.6"
    config.hosts << "192.168.1.3"
    config.hosts << "192.168.10.100"
    config.action_cable.allowed_request_origins = ['http://192.168.10.100:3001/','http://192.168.1.3:3001/']

    expose_headers = ['Access-Token', 'Uid','Client','Token-Type','Expiry', 'Authorization']

    # config.middleware.use Rack::Cors do
    #
    #   allow do
    #     origins 'http://192.168.1.6/:8080'
    #     resource '*',
    #              headers: :any,
    #              methods: :any,
    #              expose: expose_headers,
    #              credentials: false
    #   end
    #
    #   allow do
    #     origins '*'
    #     resource '/*', :headers => :any, :methods => [:get, :post, :options]
    #   end
    # end
  end
end


