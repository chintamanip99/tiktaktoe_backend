Rails.application.config.session_store :disabled
