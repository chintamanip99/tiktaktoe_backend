class JwtBlackList < ApplicationRecord
end
