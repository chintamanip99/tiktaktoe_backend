class JwtCache < ApplicationRecord
end
